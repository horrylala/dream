package com.example.my.musicplayer;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView musicListView = null;
    List<Mp3Info> mp3Infos = null;
    ServiceConnection serviceConnection = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        musicListView = (ListView) findViewById(R.id.li);
        musicListView.setOnItemClickListener(new MusicListItemClickListener());
        mp3Infos = getMp3Infos();
        SetListAdapter(mp3Infos);
        serviceConnection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                PlayerService.MyBinder myBinder = (PlayerService.MyBinder) service;
                PlayerService playerService = myBinder.getService();
                //playerService.play(0);
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {

            }
        };
    }



    /**
     * 用于从数据库中查询歌曲的信息，保存在List当中
     *
     * @return
     */
    public List<Mp3Info> getMp3Infos() {
        Cursor cursor = getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, null, null, null,
                MediaStore.Audio.Media.DEFAULT_SORT_ORDER);
        List<Mp3Info> mp3Infos = new ArrayList<Mp3Info>();
        for (int i = 0; i < cursor.getCount(); i++) {
            Mp3Info mp3Info = new Mp3Info();
            cursor.moveToNext();
            long id = cursor.getLong(cursor
                    .getColumnIndex(MediaStore.Audio.Media._ID));	//音乐id
            String title = cursor.getString((cursor
                    .getColumnIndex(MediaStore.Audio.Media.TITLE)));//音乐标题
            String artist = cursor.getString(cursor
                    .getColumnIndex(MediaStore.Audio.Media.ARTIST));//艺术家
            long duration = cursor.getLong(cursor
                    .getColumnIndex(MediaStore.Audio.Media.DURATION));//时长
            long size = cursor.getLong(cursor
                    .getColumnIndex(MediaStore.Audio.Media.SIZE));	//文件大小
            String url = cursor.getString(cursor
                    .getColumnIndex(MediaStore.Audio.Media.DATA));				//文件路径
            int isMusic = cursor.getInt(cursor
                    .getColumnIndex(MediaStore.Audio.Media.IS_MUSIC));//是否为音乐
            if (isMusic != 0) {		//只把音乐添加到集合当中
                mp3Info.setId(id);
                mp3Info.setTitle(title);
                mp3Info.setArtist(artist);
                mp3Info.setDuration(duration);
                mp3Info.setSize(size);
                mp3Info.setUrl(url);
                mp3Infos.add(mp3Info);
            }
        }
        return mp3Infos;
    }

    public void SetListAdapter(List<Mp3Info> mp3InfoList){
        List<HashMap<String,String>> mp3List = new ArrayList<HashMap<String,String>>();
        for (Iterator iterator = mp3InfoList.iterator();iterator.hasNext();){
            Mp3Info mp3Info = (Mp3Info)iterator.next();
            HashMap<String,String> map = new HashMap<String,String>();
            map.put("title", mp3Info.getTitle());
            map.put("Artist", mp3Info.getArtist());
            map.put("duration", String.valueOf(mp3Info.getDuration()));
            map.put("size", String.valueOf(mp3Info.getSize()));
            map.put("url", mp3Info.getUrl());
            mp3List.add(map);
        }
        SimpleAdapter myAdapter = new SimpleAdapter(this,mp3List,R.layout.music_list,new String[]{"title", "Artist", "duration"},
        new int[]{R.id.music_name,R.id.artist,R.id.music_len});
        musicListView.setAdapter(myAdapter);

    }

    public class MusicListItemClickListener implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(!mp3Infos.isEmpty()){
                Mp3Info mp3Info = mp3Infos.get(position);
                Log.i("music", mp3Info.toString());
                Intent intent = new Intent();
                intent.putExtra("url", mp3Info.getUrl());
                intent.putExtra("MSG", AppConstant.PlayerMsg.PLAY_MSG);
                Log.i("info", mp3Info.getUrl());
                intent.setClass(MainActivity.this, PlayerService.class);
               bindService(intent,serviceConnection,BIND_AUTO_CREATE);
                startService(intent);
            }

        }
    }

    public void playMusic(View view){
        Log.i("info","pressed play  button");
        view.setBackgroundResource(R.drawable.pause_music);
        Intent intent = new Intent();
        intent.putExtra("MSG", AppConstant.PlayerMsg.STOP_MSG);
        intent.setClass(MainActivity.this, PlayerService.class);
        bindService(intent, serviceConnection, BIND_AUTO_CREATE);
    }

}



